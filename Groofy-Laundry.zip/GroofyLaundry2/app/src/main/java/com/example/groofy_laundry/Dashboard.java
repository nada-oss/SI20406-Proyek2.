package com.example.groofy_laundry;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.MenuItem;
import android.view.View;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import org.jetbrains.annotations.NotNull;

public class Dashboard extends Activity implements View.OnClickListener {

    private CardView cuker,cuseuh,setrika,khusus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);


        cuker = (CardView) findViewById(R.id.cuker);
        cuseuh = (CardView) findViewById(R.id.cuseuh);
        setrika = (CardView) findViewById(R.id.setrika);
        khusus = (CardView) findViewById(R.id.khusus);

        cuker.setOnClickListener(this);
        cuseuh.setOnClickListener(this);
        setrika.setOnClickListener(this);
        khusus.setOnClickListener(this);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_nav);

        bottomNavigationView.setSelectedItemId(R.id.nav_home);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NotNull MenuItem menuItem) {
                switch (menuItem.getItemId()){
                    case R.id.nav_home:
                        return true;
                    case R.id.nav_cart:
                        startActivity(new Intent(getApplicationContext(), Pemesanan.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_chat:
                        startActivity(new Intent(getApplicationContext(), ChatActivity.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_akun:
                        startActivity(new Intent(getApplicationContext(), Profile.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });



    }

    @Override
    public void onClick(View v) {
        Intent i;

        switch (v.getId()) {
            case R.id.cuker: i = new Intent(this, Pemesanan.class); startActivity(i); break;
            case R.id.cuseuh: i = new Intent(this, Pemesanan.class); startActivity(i); break;
            case R.id.setrika: i = new Intent(this, Pemesanan.class); startActivity(i); break;
            case R.id.khusus: i = new Intent(this, Pemesanan.class); startActivity(i); break;
            default:break;
        }
    }
}